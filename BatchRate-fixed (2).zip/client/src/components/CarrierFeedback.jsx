import React, { useState, useMemo, useCallback } from 'react';
import { computeCarrierFeedback } from '../services/analyticsEngine.js';

const TIER_COLORS = {
  'Top 10%':    'bg-green-100 text-green-800',
  'Top 25%':    'bg-green-50 text-green-700',
  'Top 50%':    'bg-amber-50 text-amber-700',
  'Bottom 50%': 'bg-red-50 text-red-700',
};
const STOPLIGHT_BG   = { green: 'bg-green-500',  yellow: 'bg-amber-400',  red: 'bg-red-500'  };
const STOPLIGHT_RING = { green: 'ring-green-600', yellow: 'ring-amber-500', red: 'ring-red-600' };
const STOPLIGHT_TEXT = { green: 'text-green-700', yellow: 'text-amber-700', red: 'text-red-700' };
const STOPLIGHT_ROW  = { green: '', yellow: 'bg-amber-50/40', red: 'bg-red-50/40' };
const STATUS_COLORS  = {
  'Low Cost Winner':    'text-green-700 font-semibold',
  'Within 5% of best': 'text-green-600',
  'Within 10% of best':'text-amber-600',
};

function fmtMoney(v) {
  if (v == null) return '—';
  return '$' + Number(v).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function fmtPct(v) {
  if (v == null) return '—';
  return Number(v).toFixed(1) + '%';
}
function escCsv(val) {
  const s = String(val ?? '');
  return (s.includes(',') || s.includes('"') || s.includes('\n')) ? `"${s.replace(/"/g, '""')}"` : s;
}

function Dot({ light, size = 'md' }) {
  const sz = size === 'sm' ? 'w-2.5 h-2.5' : 'w-3.5 h-3.5';
  const titles = { green: '≤5% gap', yellow: '5–15% gap', red: '>15% gap' };
  return (
    <span className={`inline-block rounded-full ring-1 ring-inset ${sz} ${STOPLIGHT_BG[light]} ${STOPLIGHT_RING[light]}`} title={titles[light]} />
  );
}

function StoplightGrid({ stateMatrix, filterLane, onFilter }) {
  if (!stateMatrix || stateMatrix.length === 0) return null;
  const origStates = [...new Set(stateMatrix.map(r => r.orig))].sort();
  const destStates = [...new Set(stateMatrix.map(r => r.dest))].sort();
  const idx = {};
  for (const r of stateMatrix) idx[`${r.orig}|${r.dest}`] = r;

  return (
    <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
      <div className="bg-[#002144] text-white px-4 py-2 flex items-center gap-4" style={{ fontFamily: "'Montserrat', Arial, sans-serif" }}>
        <h3 className="text-sm font-semibold">State-to-State Coverage</h3>
        <div className="flex items-center gap-3 text-[10px] ml-auto">
          <span className="flex items-center gap-1"><Dot light="green" size="sm" /> Winner / ≤5% gap</span>
          <span className="flex items-center gap-1"><Dot light="yellow" size="sm" /> 5–15% gap</span>
          <span className="flex items-center gap-1"><Dot light="red" size="sm" /> &gt;15% gap</span>
          {filterLane && (
            <button onClick={() => onFilter(null)} className="ml-2 px-2 py-0.5 bg-white/20 hover:bg-white/30 rounded text-white">
              Clear filter ×
            </button>
          )}
        </div>
      </div>
      <div className="overflow-auto p-3">
        <table className="text-[10px] border-collapse">
          <thead>
            <tr>
              <th className="px-1 py-0.5 text-gray-400 font-medium text-right pr-2 whitespace-nowrap">Orig ↓ / Dest →</th>
              {destStates.map(d => (
                <th key={d} className="px-1.5 py-0.5 font-semibold text-gray-600 text-center min-w-[40px]">{d}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {origStates.map(orig => (
              <tr key={orig}>
                <td className="px-1 py-0.5 font-semibold text-gray-600 text-right pr-2 whitespace-nowrap">{orig}</td>
                {destStates.map(dest => {
                  const cell = idx[`${orig}|${dest}`];
                  const laneKey = `${orig} \u2192 ${dest}`;
                  const isActive = filterLane === laneKey;
                  if (!cell) return (
                    <td key={dest} className="px-1.5 py-0.5 text-center"><span className="text-gray-200">·</span></td>
                  );
                  const label = cell.avgGapPct === 0 ? '✓' : `+${cell.avgGapPct}%`;
                  return (
                    <td key={dest} className="px-1 py-0.5 text-center">
                      <button
                        onClick={() => onFilter(isActive ? null : laneKey)}
                        title={`${orig} → ${dest}: ${cell.lanes} lane(s), avg gap ${cell.avgGapPct}%, ${cell.shipments} shipments`}
                        className={`inline-flex flex-col items-center gap-0.5 rounded px-1 py-0.5 transition-all cursor-pointer
                          ${isActive ? 'ring-2 ring-[#39b6e6] bg-blue-50' : 'hover:bg-gray-100'}`}
                      >
                        <Dot light={cell.stoplight} size="sm" />
                        <span className={`font-medium leading-none ${STOPLIGHT_TEXT[cell.stoplight]}`}>{label}</span>
                      </button>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function CarrierFeedback({ flatRows }) {
  const allSCACs = useMemo(() => {
    const s = new Set();
    for (const r of flatRows) { if (r.hasRate && r.rate.carrierSCAC) s.add(r.rate.carrierSCAC); }
    return [...s].sort();
  }, [flatRows]);

  const [selectedSCAC, setSelectedSCAC] = useState(allSCACs[0] || '');
  const [sortKey, setSortKey]           = useState('stoplight');
  const [sortAsc, setSortAsc]           = useState(true);
  const [gridFilter, setGridFilter]     = useState(null);

  const feedback = useMemo(() => {
    if (!selectedSCAC) return null;
    return computeCarrierFeedback(flatRows, selectedSCAC);
  }, [flatRows, selectedSCAC]);

  const stoplightOrder = { red: 0, yellow: 1, green: 2 };

  const sortedLanes = useMemo(() => {
    if (!feedback) return [];
    let lanes = [...feedback.lanes];
    if (gridFilter) lanes = lanes.filter(l => l.laneKey === gridFilter);
    lanes.sort((a, b) => {
      let va = a[sortKey], vb = b[sortKey];
      if (sortKey === 'stoplight') { va = stoplightOrder[va]; vb = stoplightOrder[vb]; }
      if (typeof va === 'string') va = va.toLowerCase();
      if (typeof vb === 'string') vb = vb.toLowerCase();
      if (va < vb) return sortAsc ? -1 : 1;
      if (va > vb) return sortAsc ? 1 : -1;
      return 0;
    });
    return lanes;
  }, [feedback, sortKey, sortAsc, gridFilter]);

  const handleSort = (key) => {
    if (sortKey === key) setSortAsc(!sortAsc);
    else { setSortKey(key); setSortAsc(key === 'stoplight' || key === 'percentile'); }
  };

  const handleExport = useCallback(() => {
    if (!feedback) return;
    const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const lines = [
      'Carrier Feedback Report',
      `Carrier: ${feedback.scac} - ${feedback.carrierName}`,
      `Generated: ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}`,
      `Total Lanes: ${feedback.totalLanes}  |  Low Cost Wins: ${feedback.wins}  |  Overall Rank: ${feedback.overallTier} (${feedback.overallPercentile}th pct)`,
      '',
      ['Lane','Status','Ships','Avg Wt (lbs)','Your Rate ($)','Best Rate ($)','Gap $','Gap %',
       'Curr Disc %','Target Disc to Win','Delta to Win','Target Disc (-5%)','Delta (-5%)',
       'Percentile','Tier','Rank','Total Carriers'].map(escCsv).join(','),
    ];
    for (const l of feedback.lanes) {
      lines.push([
        l.laneKey, l.status, l.shipments, l.avgWeight,
        l.theirRate, l.bestRate,
        l.isWinner ? 0 : l.dollarGapToWin,
        l.isWinner ? '0.0%' : `+${l.gapPct}%`,
        `${l.currentDiscPct}%`,
        l.targetDiscToWin  != null ? `${l.targetDiscToWin}%`  : 'Already best',
        l.discDeltaToWin   != null ? `+${l.discDeltaToWin}%`  : '—',
        l.targetDiscMinus5 != null ? `${l.targetDiscMinus5}%` : 'Within 5%',
        l.discDeltaMinus5  != null ? `+${l.discDeltaMinus5}%` : '—',
        `${l.percentile}%`, l.tier, l.rank, l.totalCarriers,
      ].map(escCsv).join(','));
    }
    const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `BRAT_Feedback_${feedback.scac}_${ts}.csv`;
    a.click(); URL.revokeObjectURL(url);
  }, [feedback]);

  if (allSCACs.length === 0) return (
    <div className="flex-1 flex items-center justify-center">
      <p className="text-sm text-gray-400">No carrier data available.</p>
    </div>
  );

  const thCls = 'py-2 px-2 font-semibold text-gray-600 text-left cursor-pointer hover:bg-gray-100 select-none whitespace-nowrap text-xs';
  const arrow = k => sortKey === k ? (sortAsc ? ' ▲' : ' ▼') : '';
  const redCt    = feedback?.lanes.filter(l => l.stoplight === 'red').length    ?? 0;
  const yellowCt = feedback?.lanes.filter(l => l.stoplight === 'yellow').length ?? 0;
  const greenCt  = feedback?.lanes.filter(l => l.stoplight === 'green').length  ?? 0;

  return (
    <div className="flex-1 flex flex-col overflow-auto bg-gray-50">
      {/* Header bar */}
      <div className="border-b border-gray-200 bg-white px-4 py-3 flex items-center gap-4 shrink-0">
        <h3 className="text-sm font-bold text-[#002144]" style={{ fontFamily: "'Montserrat', Arial, sans-serif" }}>
          Carrier Feedback
        </h3>
        <label className="flex items-center gap-2 text-xs">
          <span className="text-gray-500">Select Carrier:</span>
          <select
            value={selectedSCAC}
            onChange={e => { setSelectedSCAC(e.target.value); setGridFilter(null); }}
            className="border border-gray-300 rounded px-2 py-1.5 text-sm font-medium"
          >
            {allSCACs.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </label>
        <div className="flex-1" />
        <button
          onClick={handleExport} disabled={!feedback}
          className="text-xs bg-[#002144] hover:bg-[#003366] disabled:bg-gray-300 text-white px-3 py-1.5 rounded font-medium transition-colors"
          style={{ fontFamily: "'Montserrat', Arial, sans-serif" }}
        >
          Export Carrier Feedback CSV
        </button>
      </div>

      {feedback && (
        <div className="p-4 space-y-4">
          {/* Summary card */}
          <div className="bg-white border border-gray-200 rounded-lg p-4">
            <div className="flex items-center gap-6 flex-wrap">
              <div>
                <div className="text-lg font-bold text-[#002144]">{feedback.scac}</div>
                <div className="text-sm text-gray-500">{feedback.carrierName}</div>
              </div>
              <div className="flex gap-6 text-sm">
                {[
                  { label: 'Lanes Rated',    value: feedback.totalLanes,    cls: 'text-[#002144]' },
                  { label: 'Shipments',      value: feedback.totalShipments, cls: 'text-[#002144]' },
                  { label: 'Low Cost Wins',  value: feedback.wins,           cls: 'text-green-600' },
                ].map(k => (
                  <div key={k.label}>
                    <div className="text-[10px] text-gray-400 uppercase">{k.label}</div>
                    <div className={`font-bold ${k.cls}`}>{k.value}</div>
                  </div>
                ))}
                <div>
                  <div className="text-[10px] text-gray-400 uppercase">Overall Rank</div>
                  <span className={`inline-block px-2 py-0.5 rounded text-xs font-semibold ${TIER_COLORS[feedback.overallTier] || 'bg-gray-100 text-gray-600'}`}>
                    {feedback.overallTier}
                  </span>
                  <div className="text-[10px] text-gray-400 mt-0.5">{feedback.overallPercentile}th percentile</div>
                </div>
              </div>
              {/* Lane health badges */}
              <div className="ml-auto flex items-center gap-2">
                <span className="text-[10px] text-gray-400 uppercase mr-1">Lane Health</span>
                {[['green',greenCt],['yellow',yellowCt],['red',redCt]].map(([light,ct]) => (
                  <span key={light} className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-semibold
                    ${light==='green'?'bg-green-100 text-green-800':light==='yellow'?'bg-amber-100 text-amber-800':'bg-red-100 text-red-800'}`}>
                    <Dot light={light} size="sm" /> {ct}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Stoplight grid */}
          <StoplightGrid stateMatrix={feedback.stateMatrix} filterLane={gridFilter} onFilter={setGridFilter} />

          {/* Lane table */}
          <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
            <div className="bg-[#002144] text-white px-4 py-2 flex items-center gap-3" style={{ fontFamily: "'Montserrat', Arial, sans-serif" }}>
              <h3 className="text-sm font-semibold">Lane Performance &amp; Discount Targets</h3>
              {gridFilter && (
                <span className="text-xs bg-[#39b6e6] px-2 py-0.5 rounded">
                  Filtered: {gridFilter}
                  <button onClick={() => setGridFilter(null)} className="ml-1 hover:opacity-75">×</button>
                </span>
              )}
              <span className="ml-auto text-[10px] text-white/60">{sortedLanes.length} lanes</span>
            </div>

            {/* Legend */}
            <div className="px-4 py-2 bg-blue-50 border-b border-blue-100 text-[10px] text-blue-700 flex gap-6 flex-wrap">
              <span><strong>Curr Disc %</strong> — avg tariff discount on this lane</span>
              <span><strong>Target to Win</strong> — disc needed to match best rate</span>
              <span><strong>Target (–5%)</strong> — disc needed to get within 5% of best</span>
              <span><strong>Delta (Δ)</strong> — additional discount pts needed above current</span>
            </div>

            <div className="overflow-auto max-h-[520px]">
              <table className="w-full text-xs border-collapse">
                <thead className="bg-gray-50 sticky top-0 z-10 shadow-sm">
                  <tr>
                    {[
                      ['stoplight', '●',              'text-center px-2'],
                      ['laneKey',   'Lane',            ''],
                      ['shipments', 'Ships',           'text-right'],
                      ['avgWeight', 'Avg Wt',          'text-right'],
                      ['theirRate', 'Your Rate',       'text-right'],
                      ['bestRate',  'Best Rate',       'text-right'],
                      ['gapPct',    'Gap',             'text-right'],
                      ['currentDiscPct',   'Curr Disc %',    'text-right'],
                      ['targetDiscToWin',  'Target to Win',  'text-right'],
                      ['discDeltaToWin',   'Δ to Win',       'text-right'],
                      ['targetDiscMinus5', 'Target (–5%)',   'text-right'],
                      ['discDeltaMinus5',  'Δ (–5%)',        'text-right'],
                      ['tier',      'Tier',            'text-center'],
                      ['status',    'Status',          ''],
                    ].map(([key, label, extra]) => (
                      <th key={key} className={`${thCls} ${extra}`} onClick={() => handleSort(key)}>
                        {label}{arrow(key)}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {sortedLanes.map(l => (
                    <tr key={l.laneKey} className={`border-b border-gray-100 hover:bg-gray-50/80 ${STOPLIGHT_ROW[l.stoplight]}`}>
                      <td className="py-2 px-2 text-center"><Dot light={l.stoplight} /></td>
                      <td className="py-2 px-2 font-mono text-[#002144] whitespace-nowrap">{l.laneKey}</td>
                      <td className="py-2 px-2 text-right">{l.shipments}</td>
                      <td className="py-2 px-2 text-right">{l.avgWeight.toLocaleString()} lbs</td>
                      <td className="py-2 px-2 text-right font-medium">{fmtMoney(l.theirRate)}</td>
                      <td className="py-2 px-2 text-right text-green-700 font-medium">{fmtMoney(l.bestRate)}</td>
                      <td className="py-2 px-2 text-right">
                        {l.isWinner
                          ? <span className="text-green-600 font-semibold">Best</span>
                          : <span className={STOPLIGHT_TEXT[l.stoplight]}>+{l.gapPct}%</span>}
                      </td>
                      <td className="py-2 px-2 text-right font-medium text-gray-700">{fmtPct(l.currentDiscPct)}</td>
                      <td className="py-2 px-2 text-right">
                        {l.targetDiscToWin != null
                          ? <span className="font-semibold text-[#002144]">{fmtPct(l.targetDiscToWin)}</span>
                          : <span className="text-green-600 text-[10px]">Already best</span>}
                      </td>
                      <td className="py-2 px-2 text-right">
                        {l.discDeltaToWin != null
                          ? <span className="text-red-600 font-semibold">+{fmtPct(l.discDeltaToWin)}</span>
                          : <span className="text-gray-300">—</span>}
                      </td>
                      <td className="py-2 px-2 text-right">
                        {l.targetDiscMinus5 != null
                          ? <span className="font-semibold text-amber-700">{fmtPct(l.targetDiscMinus5)}</span>
                          : <span className="text-green-600 text-[10px]">Within 5%</span>}
                      </td>
                      <td className="py-2 px-2 text-right">
                        {l.discDeltaMinus5 != null
                          ? <span className="text-amber-600 font-semibold">+{fmtPct(l.discDeltaMinus5)}</span>
                          : <span className="text-gray-300">—</span>}
                      </td>
                      <td className="py-2 px-2 text-center">
                        <span className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-semibold ${TIER_COLORS[l.tier] || 'bg-gray-100'}`}>
                          {l.tier}
                        </span>
                      </td>
                      <td className="py-2 px-2 whitespace-nowrap">
                        <span className={STATUS_COLORS[l.status] || STOPLIGHT_TEXT[l.stoplight]}>{l.status}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <p className="text-[10px] text-gray-400 italic">
            Discount targets are calculated from this carrier's own average tariff gross and accessorial charges per lane. Other carriers' names and rates are not disclosed.
          </p>
        </div>
      )}
    </div>
  );
}
