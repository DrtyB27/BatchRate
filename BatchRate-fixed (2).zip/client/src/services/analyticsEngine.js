/**
 * Pure computation functions for the Analytics Dashboard.
 * All functions take flatRows as input and return derived data.
 * NO side effects, NO DOM access.
 */

export function getLaneKey(row) {
  return `${row.origState} → ${row.destState}`;
}

function mean(arr) {
  if (arr.length === 0) return 0;
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

// ============================================================
// Minimum Rate Detection
// ============================================================
export function isMinimumRated(rate) {
  if (!rate || !rate.ratingDescription) return false;
  const desc = rate.ratingDescription.toLowerCase();
  return desc.includes('absolute minimum') || desc.includes('tariff minimum');
}

// ============================================================
// Find the low-cost carrier per reference (lowest totalCharge)
// ============================================================
export function getLowCostByReference(flatRows) {
  const groups = {};
  for (const row of flatRows) {
    if (!row.hasRate || row.rate.validRate === 'false') continue;
    const ref = row.reference || '';
    if (!groups[ref]) groups[ref] = [];
    groups[ref].push(row);
  }

  const winners = {};
  for (const [ref, rows] of Object.entries(groups)) {
    let best = null;
    for (const r of rows) {
      const tc = r.rate.totalCharge ?? Infinity;
      if (!best || tc < (best.rate.totalCharge ?? Infinity)) {
        best = r;
      }
    }
    if (best) winners[ref] = best;
  }
  return winners;
}

// ============================================================
// PANEL 1: Carrier Low Cost Ranking
// ============================================================
export function computeCarrierRanking(flatRows) {
  const validRows = flatRows.filter(r => r.hasRate && r.rate.validRate !== 'false');
  const winners = getLowCostByReference(flatRows);

  const uniqueRefs = new Set(Object.keys(winners));
  const totalUniqueRefs = uniqueRefs.size;

  const byCarrier = {};
  for (const row of validRows) {
    const scac = row.rate.carrierSCAC || 'UNKNOWN';
    if (!byCarrier[scac]) {
      byCarrier[scac] = { scac, name: row.rate.carrierName || '', rows: [], wins: 0 };
    }
    byCarrier[scac].rows.push(row);
  }

  for (const winner of Object.values(winners)) {
    const scac = winner.rate.carrierSCAC || 'UNKNOWN';
    if (byCarrier[scac]) byCarrier[scac].wins++;
  }

  const result = Object.values(byCarrier).map(c => {
    const discRows = c.rows.filter(r => !r.rate.isMinimumRated);
    const minRows = c.rows.filter(r => r.rate.isMinimumRated);
    return {
      scac: c.scac,
      carrierName: c.name,
      lowCostWins: c.wins,
      winRate: totalUniqueRefs > 0 ? (c.wins / totalUniqueRefs) * 100 : 0,
      avgTotalCharge: mean(c.rows.map(r => r.rate.totalCharge ?? 0)),
      avgTariffDiscPct: mean(discRows.map(r => r.rate.tariffDiscountPct ?? 0)),
      totalShipmentsRated: c.rows.length,
      minRatedCount: minRows.length,
      discRatedCount: discRows.length,
    };
  });

  result.sort((a, b) => b.lowCostWins - a.lowCostWins);
  return result;
}

// ============================================================
// PANEL 2: Estimated Spend Award
// ============================================================
export function computeSpendAward(flatRows) {
  const winners = getLowCostByReference(flatRows);

  const byCarrier = {};
  for (const [, row] of Object.entries(winners)) {
    const scac = row.rate.carrierSCAC || 'UNKNOWN';
    const laneKey = getLaneKey(row);
    if (!byCarrier[scac]) {
      byCarrier[scac] = { scac, name: row.rate.carrierName || '', lanes: new Set(), shipments: 0, spend: 0, minCount: 0, discCount: 0 };
    }
    byCarrier[scac].lanes.add(laneKey);
    byCarrier[scac].shipments++;
    byCarrier[scac].spend += row.rate.totalCharge ?? 0;
    if (row.rate.isMinimumRated) {
      byCarrier[scac].minCount++;
    } else {
      byCarrier[scac].discCount++;
    }
  }

  const totalSpend = Object.values(byCarrier).reduce((sum, c) => sum + c.spend, 0);

  const result = Object.values(byCarrier).map(c => ({
    scac: c.scac,
    carrierName: c.name,
    lanesAwarded: c.lanes.size,
    shipments: c.shipments,
    minRatedCount: c.minCount,
    discRatedCount: c.discCount,
    totalSpend: c.spend,
    pctOfSpend: totalSpend > 0 ? (c.spend / totalSpend) * 100 : 0,
  }));

  result.sort((a, b) => b.totalSpend - a.totalSpend);
  return { rows: result, totalSpend };
}

// ============================================================
// PANEL 3: Lane Comparison Table
// filter: 'discount' | 'minimum' | 'all'
// ============================================================
export function computeLaneComparison(flatRows, filter = 'all') {
  let validRows = flatRows.filter(r => r.hasRate && r.rate.validRate !== 'false');

  if (filter === 'discount') {
    validRows = validRows.filter(r => !r.rate.isMinimumRated);
  } else if (filter === 'minimum') {
    validRows = validRows.filter(r => r.rate.isMinimumRated);
  }

  const groups = {};
  for (const row of validRows) {
    const laneKey = getLaneKey(row);
    const scac = row.rate.carrierSCAC || 'UNKNOWN';
    const key = `${laneKey}||${scac}`;
    if (!groups[key]) {
      groups[key] = { laneKey, scac, carrierName: row.rate.carrierName || '', rows: [] };
    }
    groups[key].rows.push(row);
  }

  const result = Object.values(groups).map(g => {
    const minRows = g.rows.filter(r => r.rate.isMinimumRated);
    const discRows = g.rows.filter(r => !r.rate.isMinimumRated);

    const base = {
      laneKey: g.laneKey,
      scac: g.scac,
      carrierName: g.carrierName,
      shipments: g.rows.length,
      avgWeight: mean(g.rows.map(r => parseFloat(r.inputNetWt) || 0)),
      avgTotalCharge: mean(g.rows.map(r => r.rate.totalCharge ?? 0)),
      lowCostWinner: false,
    };

    if (filter === 'discount') {
      base.avgTariffGross = mean(g.rows.map(r => r.rate.tariffGross ?? 0));
      base.avgDiscountPct = mean(g.rows.map(r => r.rate.tariffDiscountPct ?? 0));
    } else if (filter === 'minimum') {
      base.avgMinCharge = mean(g.rows.map(r => r.rate.netCharge ?? 0));
    } else {
      // 'all'
      base.minCount = minRows.length;
      base.discCount = discRows.length;
      base.avgDiscPctDiscOnly = discRows.length > 0 ? mean(discRows.map(r => r.rate.tariffDiscountPct ?? 0)) : null;
    }

    return base;
  });

  // Determine low-cost winner per lane + compute lane average benchmark
  const byLane = {};
  for (const r of result) {
    if (!byLane[r.laneKey]) byLane[r.laneKey] = [];
    byLane[r.laneKey].push(r);
  }
  for (const rows of Object.values(byLane)) {
    const minAvg = Math.min(...rows.map(r => r.avgTotalCharge));
    const laneAvg = mean(rows.map(r => r.avgTotalCharge));
    for (const r of rows) {
      if (r.avgTotalCharge === minAvg) r.lowCostWinner = true;
      r.laneAvgBenchmark = laneAvg;
    }
  }

  result.sort((a, b) => {
    const laneCmp = a.laneKey.localeCompare(b.laneKey);
    if (laneCmp !== 0) return laneCmp;
    return a.avgTotalCharge - b.avgTotalCharge;
  });

  return result;
}

// ============================================================
// PANEL 4: Discount Comparison Heatmap
// ONLY discount-rated shipments (isMinimumRated === false)
// ============================================================
export function computeDiscountHeatmap(flatRows) {
  const validRows = flatRows.filter(
    r => r.hasRate && r.rate.validRate !== 'false' && !r.rate.isMinimumRated
  );

  const lanes = new Set();
  const carriers = new Set();
  const groups = {};

  for (const row of validRows) {
    const laneKey = getLaneKey(row);
    const scac = row.rate.carrierSCAC || 'UNKNOWN';
    lanes.add(laneKey);
    carriers.add(scac);
    const key = `${laneKey}||${scac}`;
    if (!groups[key]) groups[key] = [];
    groups[key].push(row.rate.tariffDiscountPct ?? 0);
  }

  const sortedLanes = [...lanes].sort();
  const sortedCarriers = [...carriers].sort();

  const cells = {};
  let minDisc = Infinity;
  let maxDisc = -Infinity;

  for (const [key, pcts] of Object.entries(groups)) {
    const avg = mean(pcts);
    cells[key] = avg;
    if (avg < minDisc) minDisc = avg;
    if (avg > maxDisc) maxDisc = avg;
  }

  const laneAvgs = {};
  for (const lane of sortedLanes) {
    const vals = sortedCarriers
      .map(c => cells[`${lane}||${c}`])
      .filter(v => v !== undefined);
    laneAvgs[lane] = vals.length > 0 ? mean(vals) : null;
  }

  const carrierAvgs = {};
  for (const carrier of sortedCarriers) {
    const vals = sortedLanes
      .map(l => cells[`${l}||${carrier}`])
      .filter(v => v !== undefined);
    carrierAvgs[carrier] = vals.length > 0 ? mean(vals) : null;
  }

  return {
    lanes: sortedLanes,
    carriers: sortedCarriers,
    cells,
    laneAvgs,
    carrierAvgs,
    minDisc: minDisc === Infinity ? 0 : minDisc,
    maxDisc: maxDisc === -Infinity ? 100 : maxDisc,
  };
}

// ============================================================
// YIELD OPTIMIZER: Computation Engine
// ============================================================

/**
 * Compute yield analysis for the current markup configuration.
 * Uses low-cost winners per reference and applies markups on-the-fly.
 */
export function computeYieldAnalysis(flatRows, markups, applyMarginFn) {
  const winners = getLowCostByReference(flatRows);
  const rows = [];
  let totalCost = 0, totalRevenue = 0, totalHistoric = 0;

  for (const [ref, row] of Object.entries(winners)) {
    const cost = row.rate.totalCharge ?? 0;
    const scac = row.rate.carrierSCAC || '';
    const { customerPrice, marginType, marginValue, isOverride } =
      applyMarginFn(cost, scac, markups);
    const historic = row.historicCost || 0;

    totalCost += cost;
    totalRevenue += customerPrice;
    totalHistoric += historic;

    rows.push({
      reference: ref,
      laneKey: getLaneKey(row),
      scac,
      carrierName: row.rate.carrierName || '',
      cost,
      markupType: marginType,
      markupValue: marginValue,
      isOverride: !!isOverride,
      revenue: customerPrice,
      margin: customerPrice - cost,
      marginPct: customerPrice > 0 ? ((customerPrice - cost) / customerPrice) * 100 : 0,
      historicCost: historic,
      customerSaves: historic > 0 ? historic - customerPrice : null,
      customerSavesPct: historic > 0 ? ((historic - customerPrice) / historic) * 100 : null,
    });
  }

  // Per-carrier breakdown
  const carrierYield = {};
  for (const r of rows) {
    if (!carrierYield[r.scac]) {
      carrierYield[r.scac] = {
        scac: r.scac, carrierName: r.carrierName,
        shipments: 0, cost: 0, revenue: 0, margin: 0,
        markupType: r.markupType, markupValue: r.markupValue, isOverride: r.isOverride,
      };
    }
    const c = carrierYield[r.scac];
    c.shipments++;
    c.cost += r.cost;
    c.revenue += r.revenue;
    c.margin += r.margin;
  }
  const carrierRows = Object.values(carrierYield).map(c => ({
    ...c,
    marginPct: c.revenue > 0 ? (c.margin / c.revenue) * 100 : 0,
  })).sort((a, b) => b.cost - a.cost);

  return {
    rows,
    carrierRows,
    totals: {
      cost: totalCost,
      revenue: totalRevenue,
      margin: totalRevenue - totalCost,
      marginPct: totalRevenue > 0 ? ((totalRevenue - totalCost) / totalRevenue) * 100 : 0,
      historicSpend: totalHistoric,
      customerSaves: totalHistoric > 0 ? totalHistoric - totalRevenue : null,
      customerSavesPct: totalHistoric > 0 ? ((totalHistoric - totalRevenue) / totalHistoric) * 100 : null,
    },
  };
}

/**
 * Solve for a target markup given constraints.
 */
export function solveForTarget(totalCost, historicSpend, target) {
  if (target.type === 'savings') {
    const customerPrice = historicSpend * (1 - target.savingsPct / 100);
    const markup = ((customerPrice / totalCost) - 1) * 100;
    const margin = customerPrice - totalCost;
    const marginPct = customerPrice > 0 ? (margin / customerPrice) * 100 : 0;
    return { feasible: markup >= 0, markup: Math.max(0, markup), customerPrice, margin, marginPct, customerSaves: target.savingsPct };
  }

  if (target.type === 'margin') {
    const markup = (1 / (1 - target.marginPct / 100) - 1) * 100;
    const customerPrice = totalCost * (1 + markup / 100);
    const customerSaves = historicSpend > 0 ? ((historicSpend - customerPrice) / historicSpend) * 100 : 0;
    return { feasible: true, markup, customerPrice, margin: customerPrice - totalCost, marginPct: target.marginPct, customerSaves };
  }

  if (target.type === 'dual') {
    const minPriceForSavings = historicSpend * (1 - target.savingsPct / 100);
    const markupForMargin = (1 / (1 - target.marginPct / 100) - 1) * 100;
    const priceAtMarginMarkup = totalCost * (1 + markupForMargin / 100);
    const feasible = priceAtMarginMarkup <= minPriceForSavings;

    if (feasible) {
      const actualSaves = ((historicSpend - priceAtMarginMarkup) / historicSpend) * 100;
      return {
        feasible: true, markup: markupForMargin,
        customerPrice: priceAtMarginMarkup,
        margin: priceAtMarginMarkup - totalCost,
        marginPct: target.marginPct,
        customerSaves: actualSaves,
      };
    } else {
      const maxSavingsAtMargin = ((historicSpend - priceAtMarginMarkup) / historicSpend) * 100;
      const maxMarginAtSavings = minPriceForSavings > 0
        ? ((minPriceForSavings - totalCost) / minPriceForSavings) * 100 : 0;
      return {
        feasible: false, markup: markupForMargin,
        maxSavingsAtTargetMargin: maxSavingsAtMargin,
        maxMarginAtTargetSavings: maxMarginAtSavings,
      };
    }
  }

  return { feasible: false, markup: 0 };
}

/**
 * Generate sensitivity curve data for the markup/savings/margin tradeoff.
 */
export function generateSensitivityCurve(totalCost, historicSpend, steps = 30) {
  const points = [];
  for (let i = 0; i <= steps; i++) {
    const markup = (i / steps) * 30; // 0% to 30%
    const revenue = totalCost * (1 + markup / 100);
    const margin = revenue - totalCost;
    const marginPct = revenue > 0 ? (margin / revenue) * 100 : 0;
    const customerSaves = historicSpend > 0 ? ((historicSpend - revenue) / historicSpend) * 100 : 0;
    points.push({ markup, revenue, margin, marginPct, customerSaves });
  }
  const breakeven = historicSpend > 0 ? ((historicSpend / totalCost) - 1) * 100 : null;
  return { points, breakeven };
}

/**
 * Auto-tune per-SCAC overrides to maximize customer savings
 * while keeping every carrier above marginFloor.
 */
export function optimizePerScac(flatRows, markups, marginFloor, applyMarginFn) {
  const yield0 = computeYieldAnalysis(flatRows, markups, applyMarginFn);
  const overrides = [];

  for (const carrier of yield0.carrierRows) {
    if (carrier.marginPct > marginFloor + 2) {
      const headroom = carrier.marginPct - marginFloor;
      const reduction = Math.min(headroom - 1, 3);
      const currentMarkup = carrier.markupValue || markups.default?.value || 0;
      const newMarkup = Math.max(0, currentMarkup - reduction);
      overrides.push({
        scac: carrier.scac,
        type: markups.default?.type || '%',
        value: Math.round(newMarkup * 10) / 10,
      });
    }
  }

  return overrides;
}

// ============================================================
// CSV / XLSX Export helpers
// ============================================================
function escCsv(val) {
  const s = String(val ?? '');
  if (s.includes(',') || s.includes('"') || s.includes('\n')) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

export function buildAnalyticsCsv(flatRows, heatmapData) {
  const lines = [];

  // Section 1: Lane Comparison — Discount-Rated
  const discData = computeLaneComparison(flatRows, 'discount');
  lines.push('LANE COMPARISON — DISCOUNT-RATED');
  lines.push(['Lane', 'SCAC', 'Carrier Name', '# Disc Rated Shipments', 'Avg Weight',
    'Avg Tariff Gross', 'Avg Discount %', 'Avg Total Charge', 'Low Cost Winner'].map(escCsv).join(','));
  for (const r of discData) {
    lines.push([
      r.laneKey, r.scac, r.carrierName, r.shipments,
      r.avgWeight.toFixed(1), (r.avgTariffGross ?? 0).toFixed(2),
      (r.avgDiscountPct ?? 0).toFixed(1), r.avgTotalCharge.toFixed(2),
      r.lowCostWinner ? 'Y' : '',
    ].map(escCsv).join(','));
  }

  lines.push('');

  // Section 2: Lane Comparison — Minimum-Rated
  const minData = computeLaneComparison(flatRows, 'minimum');
  lines.push('LANE COMPARISON — MINIMUM-RATED');
  lines.push(['Lane', 'SCAC', 'Carrier Name', '# Min Rated Shipments', 'Avg Weight',
    'Avg Min Charge', 'Avg Total Charge', 'Low Cost Winner'].map(escCsv).join(','));
  for (const r of minData) {
    lines.push([
      r.laneKey, r.scac, r.carrierName, r.shipments,
      r.avgWeight.toFixed(1), (r.avgMinCharge ?? 0).toFixed(2),
      r.avgTotalCharge.toFixed(2),
      r.lowCostWinner ? 'Y' : '',
    ].map(escCsv).join(','));
  }

  lines.push('');

  // Section 3: Discount Comparison Heatmap
  lines.push('DISCOUNT COMPARISON HEATMAP');
  lines.push(['Lane', ...heatmapData.carriers, 'Lane Avg'].map(escCsv).join(','));
  for (const lane of heatmapData.lanes) {
    const row = [lane];
    for (const carrier of heatmapData.carriers) {
      const val = heatmapData.cells[`${lane}||${carrier}`];
      row.push(val !== undefined ? val.toFixed(1) : '');
    }
    row.push(heatmapData.laneAvgs[lane] != null ? heatmapData.laneAvgs[lane].toFixed(1) : '');
    lines.push(row.map(escCsv).join(','));
  }
  const avgRow = ['Carrier Avg'];
  for (const carrier of heatmapData.carriers) {
    avgRow.push(heatmapData.carrierAvgs[carrier] != null ? heatmapData.carrierAvgs[carrier].toFixed(1) : '');
  }
  avgRow.push('');
  lines.push(avgRow.map(escCsv).join(','));

  return lines.join('\n');
}

export function buildAnalyticsXlsx(flatRows, heatmapData) {
  if (typeof window !== 'undefined' && window.XLSX) {
    const XLSX = window.XLSX;
    const wb = XLSX.utils.book_new();

    // Sheet 1: Lane Comparison (Discount-Rated)
    const discData = computeLaneComparison(flatRows, 'discount');
    const discRows = [
      ['Lane', 'SCAC', 'Carrier Name', '# Disc Rated Shipments', 'Avg Weight',
        'Avg Tariff Gross', 'Avg Discount %', 'Avg Total Charge', 'Low Cost Winner'],
      ...discData.map(r => [
        r.laneKey, r.scac, r.carrierName, r.shipments,
        parseFloat(r.avgWeight.toFixed(1)), parseFloat((r.avgTariffGross ?? 0).toFixed(2)),
        parseFloat((r.avgDiscountPct ?? 0).toFixed(1)), parseFloat(r.avgTotalCharge.toFixed(2)),
        r.lowCostWinner ? 'Y' : '',
      ]),
    ];
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(discRows), 'Lane Comparison (Disc)');

    // Sheet 2: Lane Comparison (Minimum-Rated)
    const minData = computeLaneComparison(flatRows, 'minimum');
    const minRows = [
      ['Lane', 'SCAC', 'Carrier Name', '# Min Rated Shipments', 'Avg Weight',
        'Avg Min Charge', 'Avg Total Charge', 'Low Cost Winner'],
      ...minData.map(r => [
        r.laneKey, r.scac, r.carrierName, r.shipments,
        parseFloat(r.avgWeight.toFixed(1)), parseFloat((r.avgMinCharge ?? 0).toFixed(2)),
        parseFloat(r.avgTotalCharge.toFixed(2)),
        r.lowCostWinner ? 'Y' : '',
      ]),
    ];
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(minRows), 'Lane Comparison (Min)');

    // Sheet 3: Discount Comparison Heatmap
    const heatRows = [
      ['Lane', ...heatmapData.carriers, 'Lane Avg'],
      ...heatmapData.lanes.map(lane => {
        const row = [lane];
        for (const carrier of heatmapData.carriers) {
          const val = heatmapData.cells[`${lane}||${carrier}`];
          row.push(val !== undefined ? parseFloat(val.toFixed(1)) : '');
        }
        row.push(heatmapData.laneAvgs[lane] != null ? parseFloat(heatmapData.laneAvgs[lane].toFixed(1)) : '');
        return row;
      }),
    ];
    const heatAvgRow = ['Carrier Avg'];
    for (const carrier of heatmapData.carriers) {
      heatAvgRow.push(heatmapData.carrierAvgs[carrier] != null ? parseFloat(heatmapData.carrierAvgs[carrier].toFixed(1)) : '');
    }
    heatAvgRow.push('');
    heatRows.push(heatAvgRow);
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(heatRows), 'Discount Heatmap');

    return XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  }
  return null;
}

// ============================================================
// SCENARIO BUILDER: Computation Engine
// ============================================================

/**
 * Compute scenario awards given a set of eligible carrier SCACs.
 * For each reference, award to lowest-cost eligible carrier.
 */
export function computeScenario(flatRows, eligibleSCACs) {
  const eligibleSet = new Set(eligibleSCACs.map(s => s.toUpperCase()));
  const refGroups = {};

  for (const row of flatRows) {
    if (!row.hasRate || row.rate.validRate === 'false') continue;
    const scac = (row.rate.carrierSCAC || '').toUpperCase();
    if (!eligibleSet.has(scac)) continue;
    const ref = row.reference || '';
    if (!refGroups[ref]) refGroups[ref] = [];
    refGroups[ref].push(row);
  }

  const allRefs = new Set(flatRows.map(r => r.reference || ''));
  const awards = {};
  const unserviced = [];

  for (const ref of allRefs) {
    const candidates = refGroups[ref];
    if (!candidates || candidates.length === 0) {
      unserviced.push(ref);
      continue;
    }
    let best = null;
    for (const r of candidates) {
      const tc = r.rate.totalCharge ?? Infinity;
      if (!best || tc < (best.rate.totalCharge ?? Infinity)) best = r;
    }
    if (best) {
      awards[ref] = {
        scac: best.rate.carrierSCAC,
        carrierName: best.rate.carrierName,
        totalCharge: best.rate.totalCharge,
        isMinimumRated: best.rate.isMinimumRated,
        tariffDiscountPct: best.rate.tariffDiscountPct,
        laneKey: getLaneKey(best),
        row: best,
      };
    }
  }

  // Summary
  const awardedList = Object.values(awards);
  const discAwarded = awardedList.filter(a => !a.isMinimumRated);
  const summary = {
    totalSpend: awardedList.reduce((s, a) => s + (a.totalCharge ?? 0), 0),
    carrierCount: new Set(awardedList.map(a => a.scac)).size,
    shipmentsAwarded: awardedList.length,
    unservicedCount: unserviced.length,
    minRatedCount: awardedList.filter(a => a.isMinimumRated).length,
    avgDiscountPct: discAwarded.length > 0 ? mean(discAwarded.map(a => a.tariffDiscountPct ?? 0)) : 0,
  };

  // Carrier breakdown
  const carrierBreakdown = {};
  for (const a of awardedList) {
    const scac = a.scac;
    if (!carrierBreakdown[scac]) {
      carrierBreakdown[scac] = {
        carrierName: a.carrierName, shipmentCount: 0,
        lanes: new Set(), totalSpend: 0, minCount: 0, discCount: 0, discPcts: [],
      };
    }
    const cb = carrierBreakdown[scac];
    cb.shipmentCount++;
    cb.lanes.add(a.laneKey);
    cb.totalSpend += a.totalCharge ?? 0;
    if (a.isMinimumRated) cb.minCount++;
    else { cb.discCount++; cb.discPcts.push(a.tariffDiscountPct ?? 0); }
  }

  const carrierBreakdownResult = {};
  for (const [scac, cb] of Object.entries(carrierBreakdown)) {
    carrierBreakdownResult[scac] = {
      carrierName: cb.carrierName,
      shipmentCount: cb.shipmentCount,
      laneCount: cb.lanes.size,
      totalSpend: cb.totalSpend,
      pctOfSpend: summary.totalSpend > 0 ? (cb.totalSpend / summary.totalSpend) * 100 : 0,
      minCount: cb.minCount,
      discCount: cb.discCount,
      avgDiscount: cb.discPcts.length > 0 ? mean(cb.discPcts) : 0,
    };
  }

  // Lane breakdown
  const laneBreakdown = {};
  for (const [ref, a] of Object.entries(awards)) {
    const lk = a.laneKey;
    if (!laneBreakdown[lk]) {
      laneBreakdown[lk] = { shipmentCount: 0, weights: [], classes: [], totalCost: 0, detailAwards: [], scacCounts: {} };
    }
    const lb = laneBreakdown[lk];
    lb.shipmentCount++;
    const row = a.row;
    lb.weights.push(parseFloat(row.inputNetWt) || 0);
    lb.classes.push(row.inputClass || '');
    lb.totalCost += a.totalCharge ?? 0;
    lb.detailAwards.push({ reference: ref, scac: a.scac, totalCharge: a.totalCharge, isMinimumRated: a.isMinimumRated });
    lb.scacCounts[a.scac] = (lb.scacCounts[a.scac] || 0) + 1;
  }

  const laneBreakdownResult = {};
  for (const [lk, lb] of Object.entries(laneBreakdown)) {
    // Plurality winner
    let topScac = '', topCount = 0;
    for (const [scac, cnt] of Object.entries(lb.scacCounts)) {
      if (cnt > topCount) { topScac = scac; topCount = cnt; }
    }
    const isMin = lb.detailAwards.some(a => a.scac === topScac && a.isMinimumRated);
    laneBreakdownResult[lk] = {
      shipmentCount: lb.shipmentCount,
      avgWeight: mean(lb.weights),
      avgClass: lb.classes[0] || '',
      awardedSCAC: topScac,
      awardedSCACLabel: Object.keys(lb.scacCounts).length > 1 ? `${topScac} (${topCount}/${lb.shipmentCount})` : topScac,
      awardedCost: lb.totalCost,
      isMinRated: isMin,
      detailAwards: lb.detailAwards,
    };
  }

  return { awards, unserviced, summary, carrierBreakdown: carrierBreakdownResult, laneBreakdown: laneBreakdownResult };
}

/**
 * Compute "Current State" scenario from historicCarrier + historicCost.
 * Returns same shape as computeScenario for consistent rendering.
 */
export function computeCurrentState(flatRows) {
  const allRefs = new Set(flatRows.map(r => r.reference || ''));
  const refData = {};
  for (const row of flatRows) {
    const ref = row.reference || '';
    if (!refData[ref]) refData[ref] = row;
  }

  const awards = {};
  const unserviced = [];

  for (const ref of allRefs) {
    const row = refData[ref];
    if (row && row.historicCarrier) {
      awards[ref] = {
        scac: row.historicCarrier,
        carrierName: row.historicCarrier,
        totalCharge: row.historicCost || 0,
        isMinimumRated: false,
        tariffDiscountPct: 0,
        laneKey: getLaneKey(row),
        row,
      };
    } else {
      unserviced.push(ref);
    }
  }

  const awardedList = Object.values(awards);
  const summary = {
    totalSpend: awardedList.reduce((s, a) => s + (a.totalCharge ?? 0), 0),
    carrierCount: new Set(awardedList.map(a => a.scac)).size,
    shipmentsAwarded: awardedList.length,
    unservicedCount: unserviced.length,
    minRatedCount: 0,
    avgDiscountPct: 0,
  };

  const carrierBreakdown = {};
  for (const a of awardedList) {
    const scac = a.scac;
    if (!carrierBreakdown[scac]) {
      carrierBreakdown[scac] = { carrierName: scac, shipmentCount: 0, laneCount: 0, totalSpend: 0, pctOfSpend: 0, minCount: 0, discCount: 0, avgDiscount: 0, lanes: new Set() };
    }
    carrierBreakdown[scac].shipmentCount++;
    carrierBreakdown[scac].lanes.add(a.laneKey);
    carrierBreakdown[scac].totalSpend += a.totalCharge ?? 0;
  }
  for (const cb of Object.values(carrierBreakdown)) {
    cb.laneCount = cb.lanes.size;
    cb.pctOfSpend = summary.totalSpend > 0 ? (cb.totalSpend / summary.totalSpend) * 100 : 0;
    delete cb.lanes;
  }

  const laneBreakdown = {};
  for (const [ref, a] of Object.entries(awards)) {
    const lk = a.laneKey;
    if (!laneBreakdown[lk]) {
      laneBreakdown[lk] = { shipmentCount: 0, weights: [], classes: [], totalCost: 0, detailAwards: [], scacCounts: {} };
    }
    const lb = laneBreakdown[lk];
    lb.shipmentCount++;
    lb.weights.push(parseFloat(a.row.inputNetWt) || 0);
    lb.classes.push(a.row.inputClass || '');
    lb.totalCost += a.totalCharge ?? 0;
    lb.detailAwards.push({ reference: ref, scac: a.scac, totalCharge: a.totalCharge, isMinimumRated: false });
    lb.scacCounts[a.scac] = (lb.scacCounts[a.scac] || 0) + 1;
  }
  const laneBreakdownResult = {};
  for (const [lk, lb] of Object.entries(laneBreakdown)) {
    let topScac = '', topCount = 0;
    for (const [scac, cnt] of Object.entries(lb.scacCounts)) {
      if (cnt > topCount) { topScac = scac; topCount = cnt; }
    }
    laneBreakdownResult[lk] = {
      shipmentCount: lb.shipmentCount, avgWeight: mean(lb.weights), avgClass: lb.classes[0] || '',
      awardedSCAC: topScac,
      awardedSCACLabel: Object.keys(lb.scacCounts).length > 1 ? `${topScac} (${topCount}/${lb.shipmentCount})` : topScac,
      awardedCost: lb.totalCost, isMinRated: false, detailAwards: lb.detailAwards,
    };
  }

  return { awards, unserviced, summary, carrierBreakdown, laneBreakdown: laneBreakdownResult };
}

/**
 * Compute "Historic Carrier Match" scenario.
 * For each reference, find the historic carrier's NEW rated cost from batch results.
 * Returns same shape as computeScenario for consistent rendering.
 */
export function computeHistoricCarrierMatch(flatRows) {
  // Build lookup: reference → historicCarrier SCAC
  const historicMap = {};
  for (const row of flatRows) {
    const ref = row.reference || '';
    if (row.historicCarrier && !historicMap[ref]) {
      historicMap[ref] = row.historicCarrier.toUpperCase();
    }
  }

  // Build lookup: reference + SCAC → best rated row
  const ratedLookup = {};
  for (const row of flatRows) {
    if (!row.hasRate || row.rate.validRate === 'false') continue;
    const ref = row.reference || '';
    const scac = (row.rate.carrierSCAC || '').toUpperCase();
    const key = `${ref}|${scac}`;
    if (!ratedLookup[key] || row.rate.totalCharge < ratedLookup[key].rate.totalCharge) {
      ratedLookup[key] = row;
    }
  }

  const allRefs = new Set(flatRows.map(r => r.reference || ''));
  const awards = {};
  const unserviced = [];
  const unservicedReasons = {};

  for (const ref of allRefs) {
    const historicSCAC = historicMap[ref];

    if (!historicSCAC) {
      unserviced.push(ref);
      unservicedReasons[ref] = 'No historic carrier data';
      continue;
    }

    const matchKey = `${ref}|${historicSCAC}`;
    const matchedRow = ratedLookup[matchKey];

    if (matchedRow) {
      awards[ref] = {
        scac: matchedRow.rate.carrierSCAC,
        carrierName: matchedRow.rate.carrierName,
        totalCharge: matchedRow.rate.totalCharge,
        isMinimumRated: matchedRow.rate.isMinimumRated,
        tariffDiscountPct: matchedRow.rate.tariffDiscountPct,
        laneKey: getLaneKey(matchedRow),
        row: matchedRow,
        historicCost: matchedRow.historicCost || 0,
        rateDelta: matchedRow.historicCost
          ? matchedRow.rate.totalCharge - matchedRow.historicCost
          : null,
      };
    } else {
      unserviced.push(ref);
      unservicedReasons[ref] = `Historic carrier ${historicSCAC} did not return a rate`;
    }
  }

  // Summary
  const awardedList = Object.values(awards);
  const discAwarded = awardedList.filter(a => !a.isMinimumRated);
  const totalSpend = awardedList.reduce((s, a) => s + (a.totalCharge ?? 0), 0);
  const totalHistoricCost = awardedList.reduce((s, a) => s + (a.historicCost ?? 0), 0);

  const summary = {
    totalSpend,
    carrierCount: new Set(awardedList.map(a => a.scac)).size,
    shipmentsAwarded: awardedList.length,
    unservicedCount: unserviced.length,
    minRatedCount: awardedList.filter(a => a.isMinimumRated).length,
    avgDiscountPct: discAwarded.length > 0 ? mean(discAwarded.map(a => a.tariffDiscountPct ?? 0)) : 0,
    totalHistoricCost,
    rateChangeSavings: totalHistoricCost - totalSpend,
    rateChangePct: totalHistoricCost > 0
      ? ((totalHistoricCost - totalSpend) / totalHistoricCost) * 100
      : 0,
  };

  // Carrier breakdown
  const carrierBreakdown = {};
  for (const a of awardedList) {
    const scac = a.scac;
    if (!carrierBreakdown[scac]) {
      carrierBreakdown[scac] = {
        carrierName: a.carrierName, shipmentCount: 0,
        lanes: new Set(), totalSpend: 0, minCount: 0, discCount: 0, discPcts: [],
      };
    }
    const cb = carrierBreakdown[scac];
    cb.shipmentCount++;
    cb.lanes.add(a.laneKey);
    cb.totalSpend += a.totalCharge ?? 0;
    if (a.isMinimumRated) cb.minCount++;
    else { cb.discCount++; cb.discPcts.push(a.tariffDiscountPct ?? 0); }
  }

  const carrierBreakdownResult = {};
  for (const [scac, cb] of Object.entries(carrierBreakdown)) {
    carrierBreakdownResult[scac] = {
      carrierName: cb.carrierName,
      shipmentCount: cb.shipmentCount,
      laneCount: cb.lanes.size,
      totalSpend: cb.totalSpend,
      pctOfSpend: summary.totalSpend > 0 ? (cb.totalSpend / summary.totalSpend) * 100 : 0,
      minCount: cb.minCount,
      discCount: cb.discCount,
      avgDiscount: cb.discPcts.length > 0 ? mean(cb.discPcts) : 0,
    };
  }

  // Lane breakdown
  const laneBreakdown = {};
  for (const [ref, a] of Object.entries(awards)) {
    const lk = a.laneKey;
    if (!laneBreakdown[lk]) {
      laneBreakdown[lk] = { shipmentCount: 0, weights: [], classes: [], totalCost: 0, detailAwards: [], scacCounts: {}, historicCostTotal: 0 };
    }
    const lb = laneBreakdown[lk];
    lb.shipmentCount++;
    const row = a.row;
    lb.weights.push(parseFloat(row.inputNetWt) || 0);
    lb.classes.push(row.inputClass || '');
    lb.totalCost += a.totalCharge ?? 0;
    lb.historicCostTotal += a.historicCost ?? 0;
    lb.detailAwards.push({
      reference: ref, scac: a.scac, totalCharge: a.totalCharge,
      isMinimumRated: a.isMinimumRated, historicCost: a.historicCost, rateDelta: a.rateDelta,
    });
    lb.scacCounts[a.scac] = (lb.scacCounts[a.scac] || 0) + 1;
  }

  const laneBreakdownResult = {};
  for (const [lk, lb] of Object.entries(laneBreakdown)) {
    let topScac = '', topCount = 0;
    for (const [scac, cnt] of Object.entries(lb.scacCounts)) {
      if (cnt > topCount) { topScac = scac; topCount = cnt; }
    }
    const isMin = lb.detailAwards.some(a => a.scac === topScac && a.isMinimumRated);
    laneBreakdownResult[lk] = {
      shipmentCount: lb.shipmentCount,
      avgWeight: mean(lb.weights),
      avgClass: lb.classes[0] || '',
      awardedSCAC: topScac,
      awardedSCACLabel: Object.keys(lb.scacCounts).length > 1 ? `${topScac} (${topCount}/${lb.shipmentCount})` : topScac,
      awardedCost: lb.totalCost,
      isMinRated: isMin,
      detailAwards: lb.detailAwards,
      historicCost: lb.historicCostTotal,
      rateDelta: lb.historicCostTotal ? lb.totalCost - lb.historicCostTotal : null,
    };
  }

  return { awards, unserviced, unservicedReasons, summary, carrierBreakdown: carrierBreakdownResult, laneBreakdown: laneBreakdownResult };
}

/**
 * Compute deltas between two scenarios.
 */
export function computeScenarioDeltas(scenarioA, scenarioB) {
  const spendDelta = scenarioA.summary.totalSpend - scenarioB.summary.totalSpend;
  const spendPctDelta = scenarioB.summary.totalSpend > 0
    ? (spendDelta / scenarioB.summary.totalSpend) * 100 : 0;

  const laneDiffs = {};
  const allLanes = new Set([...Object.keys(scenarioA.laneBreakdown), ...Object.keys(scenarioB.laneBreakdown)]);
  for (const lk of allLanes) {
    const a = scenarioA.laneBreakdown[lk];
    const b = scenarioB.laneBreakdown[lk];
    laneDiffs[lk] = {
      costDelta: (a?.awardedCost ?? 0) - (b?.awardedCost ?? 0),
      carrierChanged: (a?.awardedSCAC || '') !== (b?.awardedSCAC || ''),
    };
  }

  return { spendDelta, spendPctDelta, laneDiffs };
}

/**
 * Build scenario comparison CSV export.
 */
export function buildScenarioCsv(scenarios) {
  const lines = [];

  // Section 1: Scenario Summary
  lines.push('SCENARIO SUMMARY');
  lines.push(['Name', 'Total Spend', '# Carriers', '# Shipments', '# Unserviced',
    '# Min Rated', 'Avg Disc %'].map(escCsv).join(','));
  for (const s of scenarios) {
    lines.push([
      s.name, s.result.summary.totalSpend.toFixed(2), s.result.summary.carrierCount,
      s.result.summary.shipmentsAwarded, s.result.summary.unservicedCount,
      s.result.summary.minRatedCount, s.result.summary.avgDiscountPct.toFixed(1),
    ].map(escCsv).join(','));
  }
  lines.push('');

  // Section 2: Carrier Breakdown
  lines.push('CARRIER BREAKDOWN');
  lines.push(['Scenario', 'SCAC', 'Carrier Name', '# Shipments', '# Lanes',
    'Total Spend', '% of Spend', '# Min Rated', '# Disc Rated', 'Avg Disc %'].map(escCsv).join(','));
  for (const s of scenarios) {
    for (const [scac, cb] of Object.entries(s.result.carrierBreakdown)) {
      lines.push([
        s.name, scac, cb.carrierName, cb.shipmentCount, cb.laneCount,
        cb.totalSpend.toFixed(2), cb.pctOfSpend.toFixed(1),
        cb.minCount, cb.discCount, cb.avgDiscount.toFixed(1),
      ].map(escCsv).join(','));
    }
  }
  lines.push('');

  // Section 3: Lane Detail Comparison
  lines.push('LANE DETAIL COMPARISON');
  const allLanes = new Set();
  for (const s of scenarios) {
    for (const lk of Object.keys(s.result.laneBreakdown)) allLanes.add(lk);
  }
  const sortedLanes = [...allLanes].sort();

  const detailHeaders = ['Lane', '# Shipments', 'Avg Weight'];
  for (const s of scenarios) {
    detailHeaders.push(`${s.name} SCAC`, `${s.name} Cost`);
  }
  lines.push(detailHeaders.map(escCsv).join(','));

  for (const lk of sortedLanes) {
    const row = [lk];
    const first = scenarios.find(s => s.result.laneBreakdown[lk]);
    const lb = first?.result.laneBreakdown[lk];
    row.push(lb?.shipmentCount ?? '', lb ? lb.avgWeight.toFixed(1) : '');
    for (const s of scenarios) {
      const slb = s.result.laneBreakdown[lk];
      row.push(slb?.awardedSCACLabel ?? '', slb ? slb.awardedCost.toFixed(2) : '');
    }
    lines.push(row.map(escCsv).join(','));
  }

  return lines.join('\n');
}

// ============================================================
// CARRIER FEEDBACK
// ============================================================
export function computeCarrierFeedback(flatRows, selectedSCAC) {
  const scacUpper = selectedSCAC.toUpperCase();
  const validRows = flatRows.filter(r => r.hasRate && r.rate.validRate !== 'false');

  // Group by lane + carrier — collect tariff fields for discount target math
  const laneCarriers = {};
  for (const row of validRows) {
    const lk = getLaneKey(row);
    const scac = (row.rate.carrierSCAC || '').toUpperCase();
    if (!laneCarriers[lk]) laneCarriers[lk] = {};
    if (!laneCarriers[lk][scac]) {
      laneCarriers[lk][scac] = {
        charges: [], weights: [], count: 0,
        tariffGross: [], tariffDiscPct: [], accTotal: [],
      };
    }
    const d = laneCarriers[lk][scac];
    d.charges.push(row.rate.totalCharge || 0);
    d.weights.push(parseFloat(row.inputNetWt) || 0);
    d.count++;
    d.tariffGross.push(row.rate.tariffGross || 0);
    d.tariffDiscPct.push(row.rate.tariffDiscountPct || 0);
    d.accTotal.push(row.rate.accTotal || 0);
  }

  // Solve: what discount % is needed off avgGross to reach targetTotal (given fixed avgAcc)?
  // totalCharge = tariffGross * (1 - disc/100) + accTotal  =>  disc = (1 - (target - acc)/gross) * 100
  function discForTarget(avgGross, avgAcc, targetTotal) {
    if (avgGross <= 0) return null;
    const net = targetTotal - avgAcc;
    if (net <= 0) return null;
    return Math.min(99.9, (1 - net / avgGross) * 100);
  }

  const avg = arr => arr.reduce((a, b) => a + b, 0) / arr.length;

  const lanes = [];
  const percentiles = [];

  for (const [lk, carriers] of Object.entries(laneCarriers)) {
    if (!carriers[scacUpper]) continue;

    const myData = carriers[scacUpper];
    const myAvg        = avg(myData.charges);
    const myAvgWeight  = avg(myData.weights);
    const myAvgGross   = avg(myData.tariffGross);
    const myAvgDiscPct = avg(myData.tariffDiscPct);
    const myAvgAcc     = avg(myData.accTotal);

    // Rank all carriers on this lane by avg totalCharge
    const allAvgs = Object.entries(carriers).map(([scac, data]) => ({
      scac,
      avg: avg(data.charges),
    })).sort((a, b) => a.avg - b.avg);

    const myRank       = allAvgs.findIndex(c => c.scac === scacUpper) + 1;
    const totalCarriers = allAvgs.length;
    const bestRate     = allAvgs[0].avg;
    const p5Target     = bestRate * 1.05; // competitive = within 5% of best
    const gapPct       = bestRate > 0 ? ((myAvg - bestRate) / bestRate) * 100 : 0;

    const percentile = totalCarriers > 1
      ? ((totalCarriers - myRank) / (totalCarriers - 1)) * 100
      : 100;

    // Stoplight: green ≤5% gap, yellow 5–15%, red >15%
    const stoplight = myRank === 1 || gapPct <= 5 ? 'green'
      : gapPct <= 15 ? 'yellow'
      : 'red';

    // Discount targets (null if already winning or math doesn't apply)
    const targetDiscToWin  = myRank === 1 ? null : discForTarget(myAvgGross, myAvgAcc, bestRate);
    const targetDiscMinus5 = (myRank === 1 || gapPct <= 5) ? null : discForTarget(myAvgGross, myAvgAcc, p5Target);
    const discDeltaToWin   = targetDiscToWin  != null ? targetDiscToWin  - myAvgDiscPct : null;
    const discDeltaMinus5  = targetDiscMinus5 != null ? targetDiscMinus5 - myAvgDiscPct : null;

    let status;
    if (myRank === 1) status = 'Low Cost Winner';
    else if (gapPct <= 5) status = 'Within 5% of best';
    else if (gapPct <= 10) status = 'Within 10% of best';
    else status = `${gapPct.toFixed(0)}% above best`;

    let tier;
    if (percentile >= 90) tier = 'Top 10%';
    else if (percentile >= 75) tier = 'Top 25%';
    else if (percentile >= 50) tier = 'Top 50%';
    else tier = 'Bottom 50%';

    lanes.push({
      laneKey: lk,
      shipments: myData.count,
      avgWeight: Math.round(myAvgWeight),
      theirRate: Math.round(myAvg * 100) / 100,
      rank: myRank,
      totalCarriers,
      percentile: Math.round(percentile * 10) / 10,
      tier,
      gapPct: Math.round(gapPct * 10) / 10,
      status,
      isWinner: myRank === 1,
      stoplight,
      currentDiscPct:    Math.round(myAvgDiscPct * 10) / 10,
      targetDiscToWin:   targetDiscToWin   != null ? Math.round(targetDiscToWin   * 10) / 10 : null,
      targetDiscMinus5:  targetDiscMinus5  != null ? Math.round(targetDiscMinus5  * 10) / 10 : null,
      discDeltaToWin:    discDeltaToWin    != null ? Math.round(discDeltaToWin    * 10) / 10 : null,
      discDeltaMinus5:   discDeltaMinus5   != null ? Math.round(discDeltaMinus5   * 10) / 10 : null,
      dollarGapToWin:    myRank === 1 ? 0 : Math.round((myAvg - bestRate) * 100) / 100,
      bestRate:          Math.round(bestRate * 100) / 100,
    });

    percentiles.push({ percentile, weight: myData.count });
  }

  // Weighted overall percentile
  const totalWeight = percentiles.reduce((s, p) => s + p.weight, 0);
  const overallPercentile = totalWeight > 0
    ? percentiles.reduce((s, p) => s + p.percentile * p.weight, 0) / totalWeight
    : 0;

  const wins = lanes.filter(l => l.isWinner).length;

  // State-to-state stoplight summary (one entry per state pair, worst stoplight wins)
  const stoplightOrder = { red: 0, yellow: 1, green: 2 };
  const stateMatrix = {};
  for (const l of lanes) {
    const parts = l.laneKey.split(' → ');
    if (parts.length !== 2) continue;
    const [orig, dest] = parts;
    const key = `${orig}|${dest}`;
    if (!stateMatrix[key] || stoplightOrder[l.stoplight] < stoplightOrder[stateMatrix[key].stoplight]) {
      stateMatrix[key] = {
        orig, dest,
        stoplight: l.stoplight,
        lanes: 0,
        winLanes: 0,
        avgGapPct: 0,
        shipments: 0,
      };
    }
    stateMatrix[key].lanes++;
    stateMatrix[key].shipments += l.shipments;
    if (l.isWinner) stateMatrix[key].winLanes++;
    stateMatrix[key].avgGapPct += l.gapPct;
  }
  for (const v of Object.values(stateMatrix)) {
    v.avgGapPct = Math.round((v.avgGapPct / v.lanes) * 10) / 10;
  }

  return {
    scac: selectedSCAC,
    carrierName: validRows.find(r =>
      (r.rate.carrierSCAC || '').toUpperCase() === scacUpper
    )?.rate.carrierName || selectedSCAC,
    totalLanes: lanes.length,
    totalShipments: lanes.reduce((s, l) => s + l.shipments, 0),
    wins,
    overallPercentile: Math.round(overallPercentile * 10) / 10,
    overallTier: overallPercentile >= 90 ? 'Top 10%'
      : overallPercentile >= 75 ? 'Top 25%'
      : overallPercentile >= 50 ? 'Top 50%' : 'Bottom 50%',
    lanes: lanes.sort((a, b) => b.percentile - a.percentile),
    stateMatrix: Object.values(stateMatrix),
  };
}

/**
 * Filter flatRows to only the winning rows from a scenario's awards.
 * Returns a subset of flatRows — one rate per reference, the one that
 * won in the scenario.
 */
export function filterRowsByScenario(flatRows, scenario) {
  if (!scenario || !scenario.result) return flatRows;

  const { awards } = scenario.result;
  if (!awards || Object.keys(awards).length === 0) return flatRows;

  // Build a lookup: reference -> winning SCAC
  const winnerMap = new Map();
  for (const [ref, award] of Object.entries(awards)) {
    winnerMap.set(ref, (award.scac || '').toUpperCase());
  }

  // Filter: keep only the row that matches the winning carrier for each ref
  const seen = new Set();
  const filtered = [];
  for (const row of flatRows) {
    const ref = row.reference || '';
    const scac = (row.rate?.carrierSCAC || '').toUpperCase();
    const winnerScac = winnerMap.get(ref);

    if (winnerScac && scac === winnerScac && !seen.has(ref)) {
      seen.add(ref);
      filtered.push(row);
    }
  }

  return filtered;
}
